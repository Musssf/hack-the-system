import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import { randomInt, randomUUID } from 'node:crypto';
import { challenges } from './challenges.js';

const app = express();
const allowed = (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',').map(s => s.trim());
app.use(cors({ origin: allowed }));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'hack-the-system', rooms: rooms.size }));
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: allowed, methods: ['GET', 'POST'] } });
const rooms = new Map();
const ROUND_SECONDS = Math.max(15, Number(process.env.ROUND_SECONDS || 45));
const cleanName = value => String(value || '').trim().replace(/[^\p{L}\p{N} _-]/gu, '').slice(0, 16);
const publicRoom = room => ({ code: room.code, hostId: room.hostId, status: room.status, players: [...room.players.values()].map(p => ({ id: p.id, name: p.name, score: p.score, ready: p.ready, connected: p.connected })), round: room.round, totalRounds: challenges.length, endsAt: room.endsAt, challenge: room.status === 'playing' ? (({ answer, hint, ...safe }) => safe)(challenges[room.round]) : null });
const emitRoom = room => io.to(room.code).emit('room:update', publicRoom(room));
const codeGen = () => { const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; return Array.from({length:6}, () => chars[randomInt(chars.length)]).join(''); };
function finishRound(room) {
  if (room.status !== 'playing') return;
  room.status = 'intermission';
  io.to(room.code).emit('round:ended', { round: room.round, answer: challenges[room.round].answer, leaderboard: [...room.players.values()].map(p => ({ name:p.name, score:p.score })).sort((a,b)=>b.score-a.score) });
  emitRoom(room);
  setTimeout(() => {
    if (!rooms.has(room.code) || room.status !== 'intermission') return;
    room.round++;
    if (room.round >= challenges.length) {
      room.status = 'finished';
      room.winner = [...room.players.values()].sort((a,b)=>b.score-a.score)[0]?.id;
      io.to(room.code).emit('game:finished', { leaderboard: [...room.players.values()].map(p => ({ id:p.id, name:p.name, score:p.score })).sort((a,b)=>b.score-a.score), winnerId: room.winner });
      emitRoom(room); return;
    }
    startRound(room);
  }, 4500);
}
function startRound(room) {
  room.status = 'playing'; room.endsAt = Date.now() + ROUND_SECONDS * 1000; room.submissions = new Set(); room.hintUsed = new Set();
  io.to(room.code).emit('round:started', { round: room.round, endsAt: room.endsAt, duration: ROUND_SECONDS });
  emitRoom(room);
  clearTimeout(room.timer);
  room.timer = setTimeout(() => finishRound(room), ROUND_SECONDS * 1000);
}
io.on('connection', socket => {
  socket.on('room:create', ({ name }, cb = () => {}) => {
    const playerName = cleanName(name); if (!playerName) return cb({ error: 'Enter a nickname first.' });
    let code; do { code = codeGen(); } while (rooms.has(code));
    const player = { id: socket.id, name: playerName, score: 0, ready: true, connected: true };
    const room = { code, hostId: socket.id, players: new Map([[socket.id, player]]), status: 'lobby', round: 0, submissions: new Set(), createdAt: Date.now() };
    rooms.set(code, room); socket.join(code); socket.data.room = code; cb({ room: publicRoom(room), playerId: socket.id }); emitRoom(room);
  });
  socket.on('room:join', ({ code, name }, cb = () => {}) => {
    const roomCode = String(code || '').toUpperCase().trim(); const room = rooms.get(roomCode); const playerName = cleanName(name);
    if (!playerName) return cb({ error: 'Enter a nickname first.' });
    if (!room) return cb({ error: 'Room not found. Check the code.' });
    if (room.status !== 'lobby') return cb({ error: 'This match has already started.' });
    if (room.players.size >= 6) return cb({ error: 'This room is full (maximum 6 players).' });
    const player = { id: socket.id, name: playerName, score: 0, ready: true, connected: true };
    room.players.set(socket.id, player); socket.join(room.code); socket.data.room = room.code; cb({ room: publicRoom(room), playerId: socket.id }); emitRoom(room);
  });
  socket.on('player:ready', ({ ready }) => { const room = rooms.get(socket.data.room); const p = room?.players.get(socket.id); if (!p || room.status !== 'lobby') return; p.ready = Boolean(ready); emitRoom(room); });
  socket.on('game:start', cb => { const room = rooms.get(socket.data.room); if (!room) return cb?.({ error: 'Room not found.' }); if (room.hostId !== socket.id) return cb?.({ error: 'Only the host can start.' }); if (room.players.size < 2) return cb?.({ error: 'At least two players are required.' }); if ([...room.players.values()].some(p => !p.ready)) return cb?.({ error: 'Everyone must be ready.' }); room.round = 0; for (const p of room.players.values()) p.score = 0; cb?.({ ok: true }); startRound(room); });
  socket.on('answer:submit', ({ answer }, cb = () => {}) => {
    const room = rooms.get(socket.data.room); const p = room?.players.get(socket.id);
    if (!room || room.status !== 'playing' || !p) return cb({ error: 'No active round.' });
    if (room.submissions.has(socket.id)) return cb({ error: 'You have already submitted this round.' });
    if (Date.now() >= room.endsAt) return cb({ error: 'Time is up.' });
    room.submissions.add(socket.id);
    const expected = challenges[room.round].answer.toLowerCase().replace(/\s/g,'');
    const submitted = String(answer || '').trim().toLowerCase().replace(/\s/g,'');
    if (submitted !== expected) { cb({ correct: false, message: 'Incorrect. You can review the clue and try again only if you have not used your submission.' }); room.submissions.delete(socket.id); return; }
    const remaining = Math.max(0, room.endsAt - Date.now()); const speedBonus = Math.round(50 * remaining / (ROUND_SECONDS * 1000));
    p.score += 100 + speedBonus; cb({ correct: true, points: 100 + speedBonus, score: p.score }); io.to(room.code).emit('player:solved', { playerId: p.id, name: p.name }); emitRoom(room);
    if ([...room.players.values()].every(player => room.submissions.has(player.id))) finishRound(room);
  });
  socket.on('hint:request', cb => { const room = rooms.get(socket.data.room); if (!room || room.status !== 'playing') return cb?.({ error: 'No active challenge.' }); const p = room.players.get(socket.id); if (!p) return; if (room.hintUsed.has(socket.id)) return cb?.({ error: 'Intel already unlocked for this round.' }); room.hintUsed.add(socket.id); p.score = Math.max(0, p.score - 20); cb?.({ hint: challenges[room.round].hint, score: p.score }); emitRoom(room); });
  socket.on('disconnect', () => { const room = rooms.get(socket.data.room); if (!room) return; const p = room.players.get(socket.id); if (p) p.connected = false; if (room.status === 'lobby') { room.players.delete(socket.id); if (room.hostId === socket.id) room.hostId = room.players.keys().next().value || null; if (!room.players.size) rooms.delete(room.code); else emitRoom(room); } else emitRoom(room); });
});
const port = Number(process.env.PORT || 5000);
httpServer.listen(port, () => console.log(`Hack the System server listening on ${port}`));
