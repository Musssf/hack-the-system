# Hack the System
A real-time competitive cyber puzzle game for 2–6 players.

## Requirements
- Node.js 20+
- MongoDB is optional for this MVP; active rooms are held in server memory.

## Run locally
1. Install dependencies: `npm install` in the root, then `npm install` in `backend` and `frontend`.
2. Copy `backend/.env.example` to `backend/.env` and set `CLIENT_ORIGIN=http://localhost:5173`.
3. Run `npm run dev` from the root.
4. Open http://localhost:5173 in multiple browsers/devices.

## Deploy
Deploy the backend as a Node web service with root directory `backend`, build command `npm install`, start command `npm start`. Set `CLIENT_ORIGIN` to the deployed frontend origin. Deploy the frontend as a static site with root directory `frontend`, build command `npm install && npm run build`, publish directory `dist`, and `VITE_SERVER_URL` set to the backend URL. Configure SPA fallback to `/index.html`.

## Notes
This is an initial playable MVP. Rooms and active match state live in server memory, so restarting the server clears rooms and a single backend instance is required. MongoDB match history, persistent sessions, Redis-based multi-instance scaling, and production abuse controls are follow-on tasks. All scoring, challenge answers and round timing are server-authoritative. Challenges are fictional puzzles and do not interact with real systems.
