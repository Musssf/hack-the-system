import React, { useEffect, useMemo, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { Shield, Terminal, Users, Zap, Copy, ArrowRight, Wifi, LockKeyhole, Trophy, Volume2, VolumeX, RotateCcw, LogOut, CheckCircle2, Timer, Cpu, Radio } from 'lucide-react';

const SERVER = import.meta.env.VITE_SERVER_URL || 'http://localhost:5000';
const socket = io(SERVER, { autoConnect: false, transports: ['websocket', 'polling'] });

export default function App() {
  const [connected, setConnected] = useState(false);
  const [screen, setScreen] = useState('home');
  const [name, setName] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [room, setRoom] = useState(null);
  const [playerId, setPlayerId] = useState('');
  const [error, setError] = useState('');
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState('');
  const [seconds, setSeconds] = useState(45);
  const [hint, setHint] = useState('');
  const [sound, setSound] = useState(true);
  const [solved, setSolved] = useState([]);
  const [roundResult, setRoundResult] = useState(null);
  const [finalResult, setFinalResult] = useState(null);
  const audioRef = useRef(null);
  const isHost = room?.hostId === playerId;
  const me = room?.players?.find(p => p.id === playerId);
  const leaderboard = useMemo(() => [...(room?.players || [])].sort((a,b) => b.score - a.score), [room?.players]);

  useEffect(() => {
    const onConnect = () => { setConnected(true); setError(''); };
    const onDisconnect = () => setConnected(false);
    const onUpdate = data => setRoom(data);
    const onStarted = data => { setScreen('game'); setAnswer(''); setFeedback(''); setHint(''); setSolved([]); setRoundResult(null); setSeconds(Math.max(0, Math.ceil((data.endsAt - Date.now()) / 1000))); beep(660, .08); };
    const onEnded = data => { setRoundResult(data); setScreen('intermission'); beep(440, .14); };
    const onSolved = data => { setSolved(prev => prev.includes(data.playerId) ? prev : [...prev, data.playerId]); if (data.playerId !== socket.id) beep(880, .05); };
    const onFinished = data => { setFinalResult(data); setScreen('finished'); beep(990, .3); };
    socket.on('connect', onConnect); socket.on('disconnect', onDisconnect); socket.on('room:update', onUpdate); socket.on('round:started', onStarted); socket.on('round:ended', onEnded); socket.on('player:solved', onSolved); socket.on('game:finished', onFinished);
    socket.connect();
    return () => { socket.off('connect', onConnect); socket.off('disconnect', onDisconnect); socket.off('room:update', onUpdate); socket.off('round:started', onStarted); socket.off('round:ended', onEnded); socket.off('player:solved', onSolved); socket.off('game:finished', onFinished); socket.disconnect(); };
  }, []);

  useEffect(() => {
    if (screen !== 'game' || !room?.endsAt) return;
    const tick = () => setSeconds(Math.max(0, Math.ceil((room.endsAt - Date.now()) / 1000)));
    tick(); const id = setInterval(tick, 200); return () => clearInterval(id);
  }, [screen, room?.endsAt]);

  function beep(freq = 600, duration = .08) {
    if (!sound) return;
    try { const Ctx = window.AudioContext || window.webkitAudioContext; const ctx = audioRef.current || new Ctx(); audioRef.current = ctx; const osc = ctx.createOscillator(); const gain = ctx.createGain(); osc.type = 'sine'; osc.frequency.value = freq; gain.gain.value = .045; osc.connect(gain); gain.connect(ctx.destination); osc.start(); gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + duration); osc.stop(ctx.currentTime + duration); } catch {}
  }
  function enterRoom(action) {
    setError(''); const playerName = name.trim(); if (!playerName) return setError('Choose a player callsign first.');
    if (!connected) return setError('Connecting to game server. Please try again in a moment.');
    socket.emit(action, action === 'room:create' ? { name: playerName } : { name: playerName, code: joinCode }, result => {
      if (result?.error) return setError(result.error);
      setRoom(result.room); setPlayerId(result.playerId); setScreen('lobby'); beep(720, .1);
    });
  }
  function startGame() { setError(''); socket.emit('game:start', result => { if (result?.error) setError(result.error); }); }
  function submitAnswer(e) { e?.preventDefault(); if (!answer.trim()) return; socket.emit('answer:submit', { answer }, result => { if (result?.error) setFeedback(result.error); else if (result.correct) { setFeedback(`ACCESS GRANTED · +${result.points} POINTS`); setAnswer(''); beep(1040, .16); } else setFeedback(result.message || 'ACCESS DENIED · TRY AGAIN'); }); }
  function requestHint() { socket.emit('hint:request', result => { if (result?.error) setFeedback(result.error); else { setHint(result.hint); setFeedback('INTEL UNLOCKED · 20 POINTS DEDUCTED'); } }); }
  async function copyCode() { try { await navigator.clipboard.writeText(room.code); setFeedback('ROOM CODE COPIED'); beep(800,.06); } catch { setFeedback(`ROOM CODE: ${room.code}`); } }
  function leave() { socket.disconnect(); socket.connect(); setRoom(null); setPlayerId(''); setScreen('home'); setError(''); setFinalResult(null); setRoundResult(null); }

  return <div className="app-shell"><div className="scanlines"/><header className="topbar"><a className="brand" onClick={() => screen === 'home' ? null : leave()}><span className="brand-mark"><Shield size={19}/></span><span>HACK<span className="green">_</span>THE<span className="green">_</span>SYSTEM</span></a><div className="top-status"><span className={`status-dot ${connected ? 'online' : ''}`}/>{connected ? 'SERVER ONLINE' : 'CONNECTING'}<button className="icon-button" onClick={() => setSound(v => !v)} title="Toggle sound">{sound ? <Volume2 size={17}/> : <VolumeX size={17}/>}</button></div></header>
  <main className="main-wrap">
    {screen === 'home' && <section className="hero"><div className="eyebrow"><span className="pulse"/> MULTIPLAYER CYBER ARENA <span className="eyebrow-line"/></div><h1>HACK THE<br/><span className="outline">SYSTEM.</span></h1><p className="hero-copy">Think fast. Crack the code. Outplay the competition.<br/>The system is waiting for someone to break in.</p><div className="hero-stats"><div><strong>02–06</strong><small>OPERATORS</small></div><div><strong>05</strong><small>ROUNDS</small></div><div><strong>045s</strong><small>PER ROUND</small></div></div><div className="entry-card"><div className="card-head"><div><span className="mini-label">// OPERATOR IDENTIFICATION</span><h2>Enter the arena</h2></div><Terminal className="card-icon" size={25}/></div><label className="field-label">YOUR CALLSIGN</label><input className="text-input" maxLength={16} value={name} onChange={e => setName(e.target.value)} placeholder="e.g. NEO_07" onKeyDown={e => e.key === 'Enter' && enterRoom('room:create')}/><div className="entry-actions"><button className="primary-button" onClick={() => enterRoom('room:create')}><Zap size={16}/> CREATE ROOM <ArrowRight size={16}/></button><div className="or-divider"><span/> OR <span/></div><div className="join-row"><input className="text-input code-input" maxLength={6} value={joinCode} onChange={e => setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,''))} placeholder="ROOM CODE"/><button className="secondary-button" onClick={() => enterRoom('room:join')}>JOIN <ArrowRight size={15}/></button></div></div>{error && <p className="error-text">{error}</p>}</div><div className="hero-foot"><span><LockKeyhole size={13}/> NO ACCOUNT REQUIRED</span><span><Wifi size={13}/> REAL-TIME MULTIPLAYER</span><span><Users size={13}/> UP TO 6 PLAYERS</span></div></section>}

    {screen === 'lobby' && room && <section className="panel-screen"><div className="eyebrow"><span className="pulse"/> SECURE CHANNEL ESTABLISHED</div><div className="screen-title-row"><div><span className="mini-label">// WAITING ROOM</span><h1 className="screen-title">ASSEMBLE YOUR<br/><span className="green">OPERATORS.</span></h1></div><div className="room-code-box"><small>ROOM ACCESS CODE</small><strong>{room.code}</strong><button onClick={copyCode}><Copy size={13}/> COPY CODE</button></div></div><div className="lobby-grid"><div className="players-panel"><div className="section-head"><h3><Users size={16}/> OPERATORS <span className="count-pill">{room.players.length}/6</span></h3><span className="live-tag">LIVE</span></div><div className="player-list">{Array.from({length:6},(_,i)=>room.players[i]).map((p,i)=><div className={`player-row ${p ? '' : 'empty'}`} key={p?.id || i}><div className="avatar">{p ? p.name.slice(0,2).toUpperCase() : <span>+</span>}</div><div className="player-meta"><strong>{p?.name || 'AWAITING OPERATOR'}</strong><small>{p?.id === room.hostId ? 'ROOM HOST' : p ? 'CONNECTED' : 'OPEN SLOT'}</small></div>{p && <span className={`ready-pill ${p.ready ? 'ready' : ''}`}>{p.ready ? 'READY' : 'NOT READY'}</span>}{p?.id === room.hostId && <span className="host-crown">HOST</span>}</div>)}</div></div><div className="mission-panel"><span className="mini-label">// MISSION PARAMETERS</span><h3>THE BREACH</h3><p>Five escalating security layers stand between your team and the mainframe. Only the sharpest operator will claim the system.</p><div className="mission-facts"><div><Timer size={15}/><span>45 SEC / ROUND</span></div><div><Cpu size={15}/><span>PROGRESSIVE DIFFICULTY</span></div><div><Trophy size={15}/><span>HIGHEST SCORE WINS</span></div></div><div className="lobby-actions">{isHost ? <button className="primary-button full" disabled={room.players.length < 2} onClick={startGame}>INITIATE BREACH <ArrowRight size={16}/></button> : <div className="waiting-message"><span className="pulse"/> WAITING FOR HOST TO INITIATE...</div>}<button className="text-button" onClick={leave}><LogOut size={14}/> LEAVE ROOM</button></div>{room.players.length < 2 && <small className="muted">At least 2 operators required to start.</small>}</div></div>{error && <p className="error-text">{error}</p>}</section>}

    {screen === 'game' && room && <section className="panel-screen game-screen"><div className="game-topline"><span className="eyebrow"><span className="pulse"/> LIVE BREACH IN PROGRESS</span><span className="round-count">ROUND {room.round + 1} <i>/</i> {room.totalRounds}</span></div><div className="game-layout"><div className="challenge-panel"><div className="challenge-type"><Radio size={14}/> {room.challenge?.type || 'SECURITY CHALLENGE'}</div><div className="challenge-heading"><div><span className="mini-label">// CURRENT OBJECTIVE</span><h2>{room.challenge?.title}</h2></div><div className={`timer ${seconds <= 10 ? 'urgent' : ''}`}><strong>{String(seconds).padStart(2,'0')}</strong><small>SECONDS</small></div></div><p className="challenge-prompt">{room.challenge?.prompt}</p><form onSubmit={submitAnswer} className="answer-form"><label className="field-label">ENTER DECRYPTED RESPONSE</label><div className="answer-row"><input className="text-input answer-input" autoComplete="off" value={answer} onChange={e=>setAnswer(e.target.value)} placeholder="TYPE YOUR ANSWER..."/><button className="primary-button" type="submit"><Zap size={15}/> SUBMIT</button></div></form>{feedback && <div className={`feedback ${feedback.includes('GRANTED') ? 'success' : ''}`}>{feedback}</div>}{hint && <div className="hint-box"><span>INTEL //</span> {hint}</div>}<button className="hint-button" onClick={requestHint}>REQUEST INTEL <span>−20 PTS</span></button><div className="solved-line"><CheckCircle2 size={14}/> {solved.length} / {room.players.length} OPERATORS SOLVED</div></div><aside className="score-panel"><div className="section-head"><h3><Trophy size={15}/> LIVE RANKING</h3><span className="live-tag">LIVE</span></div>{leaderboard.map((p,i)=><div className={`rank-row ${p.id===playerId?'self':''}`} key={p.id}><span className="rank-num">0{i+1}</span><span className="rank-name">{p.name}{p.id===playerId?' (YOU)':''}</span><strong>{p.score}</strong></div>)}<div className="score-note">SPEED BONUS: UP TO +50 PTS</div></aside></div></section>}

    {screen === 'intermission' && room && <section className="result-screen"><div className="result-icon"><CheckCircle2 size={34}/></div><span className="mini-label">// ROUND {room.round + 1} DEBRIEF</span><h1 className="screen-title">LAYER<br/><span className="green">BREACHED.</span></h1><div className="answer-reveal"><small>VERIFIED SOLUTION</small><strong>{roundResult?.answer}</strong></div><div className="result-board">{leaderboard.map((p,i)=><div className="rank-row" key={p.id}><span className="rank-num">0{i+1}</span><span className="rank-name">{p.name}</span><strong>{p.score}</strong></div>)}</div><p className="waiting-message"><span className="pulse"/> NEXT SECURITY LAYER LOADING...</p></section>}

    {screen === 'finished' && room && <section className="result-screen"><div className="result-icon trophy"><Trophy size={36}/></div><span className="mini-label">// MAINFRAME ACCESS COMPLETE</span><h1 className="screen-title">SYSTEM<br/><span className="green">BREACHED.</span></h1><p className="hero-copy">The competition is over. The leaderboard is final.</p><div className="result-board final-board">{(finalResult?.leaderboard || leaderboard).map((p,i)=><div className={`rank-row ${i===0?'champion':''}`} key={p.id}><span className="rank-num">0{i+1}</span><span className="rank-name">{p.name}{i===0?' · CHAMPION':''}</span><strong>{p.score}</strong></div>)}</div><button className="primary-button" onClick={leave}><RotateCcw size={16}/> RETURN TO BASE</button></section>}
  </main><footer className="footer"><span>HACK_THE_SYSTEM <i>v1.0.0</i></span><span>FICTIONAL CYBER PUZZLES · PLAY FAIR · THINK FAST</span><span>© 2026 CYBER ARENA</span></footer></div>;
}
